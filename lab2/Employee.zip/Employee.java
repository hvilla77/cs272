package cs272;

import java.io.*;
import java.util.*;

public class Employee implements Cloneable { //start of class
	
		//Variables for the objects, Private so that only this program can make changes. (1)
		private String employee_name = "";
		private int employee_no = 0;
		private int employee_age = 0;
		private String employee_state = "";
		private int employee_zip = 0;
		private Integer[] advisor = new Integer[3];//array will only have at least 3 advisors.
			

	

	public Employee() { //start of Employee (2.1)
		
	} // end of Employee (2.1)
	
	public Employee(Object obj) { //start of Employee (2.2)
		
		if (obj == null || !(obj instanceof Employee)) { //Start of if statement
			
			System.out.println("This is either a null object or not a Employee"); // Uncomment for testing
			
		}// end of if statement
		
		else { // start of else
			try {// start of try
			 Employee e = (Employee)super.clone();
			 e.employee_name = new String(employee_name);
			 e.employee_no = employee_no;
			 e.employee_age = employee_age;
			 e.employee_state = new String(employee_state);
			 e.employee_zip = employee_zip;
			 e.advisor = advisor;
			}// end of try
			catch(CloneNotSupportedException e) {// start of catch
				System.out.print(e.getMessage());
			}// end of catch
			
		} // end of else
	}//end of object obj function (2.2)
	
	public String getEmployeeName() { // start of get and set (2.3)
		
		return employee_name;
		
	}
	
	public void setEmployeeName(String employee_name) {
		
		this.employee_name = employee_name;
	}
	
	public int getEmployeeNo() {
		
		return employee_no;
		
	}
	
	public void setEmployeeNo(int employee_no) {
		
		this.employee_no = employee_no;
		
	}
	
	public int getEmployeeAge() {
		
		return employee_age;
	}
	
	public void setEmployeeAge(int employee_age) {
		
		this.employee_age = employee_age;
		
	}
	
	public String getEmployeeState () {
		
		return employee_state;
		
	}
	
	public void setEmployeeState (String employee_state) {
		
		this.employee_state = employee_state;
		
	}
	
	public int getEmployeeZip () {
		
		return employee_zip;
		
	}
	
	public void setEmployeeZip (int employee_zip) {
		
		this.employee_zip = employee_zip;
		
	}
	
	public Integer[] getAdvisor () {
		
		return advisor;
		
	}
	
	public void setAdvisor (Integer[] advisor) {
		
		this.advisor = advisor;
		
	}// end of get and set (2.3)
	
	public String toString() {// start of toString (2.4)
		
		String x = employee_name + "," + employee_no + "," + employee_age + "," + employee_state + "," + employee_zip + ",";
		
		for (int i = 0; i < 3; i++) {// start of for loop
			
			if (advisor[i] != null)  {// start of if
				
				x = x + advisor[i]; 
				
			}// end of if
		}// end of for loop
			
		return x;
		
	}// end of toString (2.4)
	
	public boolean equals(Object obj) {// start of boolean (2.5)
		
		if (obj != null && obj instanceof Employee) {//start of first if
			
			Employee y = new Employee(obj);
			
			if (y.employee_no == employee_no) {//start of second if
				
				return true;
				
			}//end of second if
			
		}//end of First if
		return false;
	}// end of boolean (2.5)
	
	public static int[] getAllAdvisors(Employee e1, Employee e2) {//start of getAllAdvisors (2.6)
		int count = 0;
		int[] allAdvisors = new int[6];
		int advisorcount = 0;
		
		if (e1 != null && e2 != null) { // start of if

			for (int i = 0; i < 3; i++) {// start of for 
				
				if(e1.advisor[i] != null) {// start of if
					count++;
					allAdvisors[advisorcount] = e1.advisor[i];
					advisorcount++;
				}//end of if
				
			}// end of for
			
			for (int i = 0;i < 3; i++) { //start of for
				
				if(e2.advisor[i] != null) {//start of if
					
					for(int x = 0;x < count;x++) {//start of for
						
						if(e1.advisor[x] == e2.advisor[i]) {//start of if
							break;
							
						}//end of if
						
						if(x == count-1) {//start of if
							//add e2 to total
							allAdvisors[advisorcount] = e2.advisor[i];
							advisorcount++;
						}//end of if
					}//end of for
				
				
				}//end of if
				
			}//end of for
			
			
		}// end of if
		int[] totaladvisors = new int[advisorcount];
		for(int i = 0; i < totaladvisors.length;i++) {//start of for
			
			totaladvisors[i] = allAdvisors[i];
		}//end of for
		
		return totaladvisors;
	}// end of getAllAdvisors (2.6)
	
	public static void main(String[] args) { //start of main string
		Employee test = new Employee();//for 2.1 if passes creates employeen
		System.out.println("test 2.1 passes");
		Employee test2 = new Employee(null);//for 2.2 if passes creates error message
		System.out.println("if error message appears test 2.2 passes");
		Employee test22 = new Employee(test);
		System.out.println("second test for 2.2 passes");
		test.setEmployeeName("curtis");
		System.out.println("if test 2.3 passes I excpect to see curtis");
		System.out.println(test.getEmployeeName());
		Integer[] testadvisor = {5,3,7};
		Integer[] testadvisor22 = {5,4,1};
		test22.setAdvisor(testadvisor22);
		test.setAdvisor(testadvisor);
		System.out.println("if test 2.4 I excpect to see curtis,537 and everything else to be default values.");
		System.out.println(test.toString());
		System.out.println("for test 2.6 I expect to test two employees with a same number. the 5 in test22 will be skipped"
				+ " I should see the 5,3,7,4,1");
		System.out.println(Arrays.toString(getAllAdvisors(test,test22)));
		
		
		
	

	} // end of main string
	
}// end of class


