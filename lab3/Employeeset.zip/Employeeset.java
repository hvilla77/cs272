package cs272;

import java.io.*;
import java.util.*;
import java.util.Arrays;


public class Employeeset implements Cloneable {
	//Variables for the objects, private so that only this program can make changes.
	private String employee_name = "";
	private int employee_no = 0;
	private int employee_age = 0;
	private String employee_state = "";
	private int employee_zip = 0;
	private Integer[] advisor = new Integer[3];
	private Employee[] data;
	private int counter;
	
	
	public Employeeset() {//start of 2
		final int size = 10; 
		counter = 0;
		data = new Employee[size];
		
	}
	
	public Employeeset(Object obj) { //start of Employee (3)
		
		if (obj == null || !(obj instanceof Employeeset)) { //Start of if statement
			
			System.out.println("This is either a null object or not a Employee"); // Uncomment for testing
			
		}// end of if statement
		
		else { // start of else
			try {// start of try
				Employeeset e = (Employeeset)super.clone();
			 e.employee_name = new String(employee_name);
			 e.employee_no = employee_no;
			 e.employee_age = employee_age;
			 e.employee_state = new String(employee_state);
			 e.employee_zip = employee_zip;
			 e.advisor = advisor;
			}// end of try
			catch(CloneNotSupportedException e) {// start of catch
				System.out.print(e.getMessage());
			}// end of catch
			
		} // end of else
	}//end of object obj function (3)
	
	public int sizes() {//start of finding the size (4)
		 
		return counter;
		
	}//end of finding the size (4)
	
	public int capacity() {//start of capacity (5)
		
		return data.length;
	}//end of capacity (5)
	
	
	
	public void add(Employee a) {// start of add (6)
		
		if(counter == data.length) {
			
			ensureCapacity((counter+1)*2);
			
		}
		
		data[counter] = a;
		counter++;
	}// end of add (6)
	
	public boolean contains(Employee a) {//start of contains (7)
		
		for(int i = 0; i == counter;i++) {
			
			if(a == null) {
				return false;
				
				
			}
			else if(a == data[i]) {
				return true;
			}
		}
		return false;
		
	}//end of contains (7)
	
	public boolean remove(int eno) {//start of remove (8)
		
		int index;
		for (index = 0;(index < counter) && (eno != data[index].getEmployeeNo());index++) ;
			
			if(index == counter)
				return false;
			else {
				counter--;
				data[index] = data[counter];
				return true;
			}
		
	}//end of remove (8)

	public void ensureCapacity(int mimCapacity) {//start of ensureC (9)
		
		Employee[] biggerArray;
		
		if(data.length < mimCapacity) {
			
			biggerArray = new Employee[mimCapacity];
			System.arraycopy(data,0,biggerArray,0,counter);
			data = biggerArray;
			
		}
	}//end of ensureC (9)
	
	public void addOrdered(Employee a) {//start of addO (10)
		 
		if (a != null) {
			for (int i = 0; i < counter-1; i++) {
				if(data[i].getEmployeeNo() <= data[i+1].getEmployeeNo()) {
					continue;
				}
				else {
					System.out.println("Not Sorted");
					return;
				}
			}
			add(a);	
		}
		else {
			System.out.println("Employee is null");
		}
		
			
	}//end of addo (10)

	public static void main(String[] args) {//start of testing (11)
		Employeeset x = new Employeeset ();
		for (int i = 0; i < 11;i++) {
			Employee e = new Employee();
			Random r = new Random();
			e.setEmployeeNo(r.nextInt(1000));
			x.add(e);
		}
		System.out.println("For step four works if the print on sizes is 11.");
		System.out.println(x.sizes());
		System.out.println("For step five and six works if the message appers double as "
				+ "if I put 11 i will receive a 22 meaning the array grew.");
		System.out.println(x.data.length);
			
		System.out.println("For step three you will receive a error message if employe is null");
		Employeeset test = new Employeeset (null);
		
	}//end of testing (11)
	
	
	
}// end of class
